
document.querySelectorAll("button").forEach(button => {
    button.addEventListener("click", () => {
        alert("Produit ajouté au panier !");
    });
});
